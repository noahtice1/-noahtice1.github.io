﻿using Microsoft.AspNetCore.Mvc;

namespace LCMVC1.Controllers
{
    public class SController : Controller
    {
        public string getStr()
        {
            return "this is my second controller";
        }
        public double Index()
        {
            return 128.8;
        }
    }
}
