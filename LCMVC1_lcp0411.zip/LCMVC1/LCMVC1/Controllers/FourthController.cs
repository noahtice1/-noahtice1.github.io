﻿using LCMVC1.Data;
using Microsoft.AspNetCore.Mvc;
using System.Reflection.Metadata.Ecma335;

namespace LCMVC1.Controllers
{
    public class FourthController : Controller
    {
        StudentDB db=new StudentDB();
        public IActionResult Index()
        {
            return View();
        }

        public JsonResult Getstus()
        {
            var r = db.Students;
            return Json(r);
        }
    }
}
