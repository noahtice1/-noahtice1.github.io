﻿"use strict";

{
    let tbl = document.querySelector("#tbl");

    let grid = null;

    async function ShowTable() {
        let url = rootpath + "Fourth/GetStus";
        let fd = new FormData();
        let params = { method: "post", cache: "no-store", body: fd };

        let r = await fetch(url, params);
        let rj = await r.json();

        if (grid != null) {
            grid.destroy();
        }
        tbl.innerHTML = ``;

        params = {
            data: rj,
            pagination: { limit: 5, },
            width: 800,
            search: true,
            sort: true,
            columns: [{ id: "id", Name: "ID" }, { id: "name", name: "Name" }, { id: "age", name: "Age", },
                { id: "grade", name: "Grade" }, {id:"letterGrade",name:"L.G."}
            ],
        }
        grid = new gridjs.Grid(params);
        grid.render(tbl);
    }
    ShowTable();
}