﻿"use strict";

{
    let plusbtn=document.querySelector("#plusbtn")
    let minusbtn = document.querySelector("#minusbtn")

    let x = 0;

    let tdiv = document.querySelector("#tdiv");
    function plusfun() {
        x = x + 10;
        let params = {
            targets: [tdiv,],
            
                rotate: { value: x, duration: 3000, },
        };
        anime(params);

        //swal.fire("plus");
    }
    plusbtn.addEventListener("click", plusfun);

    function minusfun() 
        {
            x = x + 0.1;
           // x = x - 10;
            let params = {
                targets: [tdiv,],
                scale:{ value: x, duration: 3000, },
            };
            anime(params);
        //swal.fire("minus");
    };
    minusbtn.addEventListener("click", minusfun);
}