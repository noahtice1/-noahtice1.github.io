﻿using LCMVC1.Data;
using LCMVC1.Models;
using Microsoft.AspNetCore.Mvc;
using System.Reflection.Metadata.Ecma335;

namespace LCMVC1.Controllers
{
    public class FourthController : Controller
    {
        StudentDB db=new StudentDB();

        public JsonResult AddStu(string n, int a, double g, string id)
        {

            Student stu = new Student();
            stu.Id = id;
            stu.Name = n;
            stu.Age = a;
            stu.Grade = g;
            stu.LetterGrade = "";

            db.Students.Add(stu);
            db.SaveChanges();

            int N = db.Students.Count();

            return Json(new {N=N,mes=$"ID:{id},Name:{n},Age{a},Grade:{g:F2}" });


            //return Json($"ID:{id},Name:{n},Age{a},Grade:{g:F2}");
        }

        public IActionResult Index()
        {
            return View();
        }

        public JsonResult Getstus()
        {
            var r = db.Students;
            return Json(r);
        }
    }
}
