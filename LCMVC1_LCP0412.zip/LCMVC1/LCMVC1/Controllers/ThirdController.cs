﻿using LCMVC1.Data;
using LCMVC1.Models;
using Microsoft.AspNetCore.Mvc;

namespace LCMVC1.Controllers
{
    public class ThirdController : Controller
    { 
        StudentDB db=new StudentDB();
   

    public JsonResult AddStu(string i,string n, int a, double g)
        {
            Student student = new Student();
            student.Id = i;
            student.Name = n;
            student.Age = a;
            student.Grade = g;
            student.LetterGrade = "";

            db.Students.Add(student);
            db.SaveChanges();

            return Json(new{ });
        }


    
        public IActionResult Index()
        {
            return View();
        }
    }
}
