﻿using LCMVC1.Data;
using Microsoft.AspNetCore.Mvc;
using SQLitePCL;

namespace LCMVC1.Controllers
{
    public class HomeController : Controller
    {

        public JsonResult GetS1()
        {
            var r=dB.Students.First();
            return Json(r);
        }


        public IActionResult GetP2()
        { return View(); }

        StudentDB dB = new StudentDB();
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult GetP()
        { return View(); }


         public int GetI() //private vs public 
        {
            return 20;
        }

        public JsonResult GD()
        {
            return Json(dB.Students);
        }
    }
}
