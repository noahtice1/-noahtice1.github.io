﻿"use strict";

{
    let opts = {
        title: "this is the third controller",
        text: "third index",
        icon: "success",
    };

    /*Swal.fire(opts);*/
}
let sid = document.querySelector("#sid");
let sname = document.querySelector("#sname");
let sage = document.querySelector("#sage");
let sgrade = document.querySelector("#sgrade");

let addbtn = document.querySelector("#addbtn");


async function addstu() {

    let id = sid.value;
    let name = sname.value;
    let age = sage.value;
    let grade = sgrade.value;

    let fd = new FormData();
    fd.append("i", id);
    fd.append("n", name);
    fd.append("a", age);
    fd.append("g", grade);

    let opts = {
        method: "post",
        body: fd,

    };
    let url = rootpath + "Third/Addstu";

    let r = await fetch(url, opts);
    let rj = await r.json();

    swal.fire(id);

}
addbtn.addEventListener("click",addstu)

