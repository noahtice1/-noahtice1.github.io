﻿
"use strict";

let b1 = document.querySelector("#b1");

function b1f()
{
    let opts = {
        title: "Title",
        text: "Text",
        icon:"error",
    };

    Swal.fire(opts);
}    


b1.addEventListener("click", b1f);

//anime
let x = 0;
let b2 = document.querySelector("#b2");
let b3 = document.querySelector("#b3");
let i1 = document.querySelector("#i1");


{
    x = x + 10;
    let opt = {
        targets: [i1],
        translateX: { value: x, duration: 3000 },
    anime(opt);
}
function b3f()
{
    x = x - 10;
    let opt = {
        targets: [i1],
        translateX: { value: x, duration: 3000 },
    anime(opt);
}
b2.addEventListener("click", b2f);
b3.addEventListener("click", b3f);