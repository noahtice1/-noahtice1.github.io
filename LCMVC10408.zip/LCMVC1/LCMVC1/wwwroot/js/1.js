﻿"use strict";

{
    let opts = {
        title: "this is the third controller",
        text: "third index",
        icon: "success",
    };

    Swal.fire(opts);
}

