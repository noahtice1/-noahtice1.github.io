﻿using Microsoft.AspNetCore.Mvc;

namespace LCMVC1.Controllers
{
    public class ThirdController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
